<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

//Route::get('/', 'DoorChatController@index');
Route::controllers([
    'auth' => 'Auth\AuthController', 
    'password' => 'Auth\PasswordController',
]);




Route::group(array('prefix'=>'v1'),function(){
	Route::post('user_register','Auth\AuthController@postRegister');
	Route::post('user_login','Auth\AuthController@postLogin');
	Route::post('user_register_fb','Auth\AuthController@postRegisterFb');
	Route::get('getEmail','Auth\PasswordController@getEmail');
	Route::post('postEmail1','Auth\PasswordController@postEmail1');
	Route::post('postEmail','Auth\PasswordController@postEmail');
	Route::get('password/reset/{token}','Auth\PasswordController@getReset');
	Route::get('/','DoorChatController@index');
	Route::post('edit_user_profile','DoorChatController@edit_user_profile');
	Route::post('get_user_profile','DoorChatController@get_user_profile');
});
	
