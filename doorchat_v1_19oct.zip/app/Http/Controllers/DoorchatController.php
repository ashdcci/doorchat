<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Response;
use Redirect;
use DB;
use app\Event;
use Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Support\JsonableInterface;
use Illuminate\Contracts\Auth\Guard;
use App\User;
use Session;
use Hash;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Storage;
use Illuminate\Contracts\Filesystem\Factory;
use File;

class DoorchatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {
        //

        return Response::json(array(
            'error'=>true,
            'content'=>'User Not Authenticate to Access this Operation.'
            ),200);
    }   



    public function edit_user_profile(Request $request){
            $rules = [
            'lat'=>'required',
            'fullname'=>'required',
            'lng'=>'required',
            'token'=>'required'
            ];
               

            $v1 = Validator::make($request->all(),$rules);
            if($v1->fails()){
                return Response::json(array(
                    'error'=>false,
                    'content'=>$v1->errors()
                    ),200);
            }
            $user = User::where('user_token', '=', $request->only('token'))->first();
            
            if($user->id>0){
               echo  $fullname  =  str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('fullname'));
         
                        if (!($request->hasFile('profile_picture'))) {
                            //profile pic not exist
                         

                            $res = DB::select(DB::raw('update tbl_user_register set fullname = "'.$fullname.'", lat ="'.$request->input('lat').'",
                            lng = "'.$request->input('lng').'" where id ='.$user->id.'  '));
                 }else{

                  
                    //delete file
                      File::delete('public/uploads/user_profile/'.$user->profile_picture);
                  
                      //move file
                    $destinationPath =   base_path() . '/public/uploads/user_profile/';
                    $fileName =rand(11111,99999).'.'.$request->file('profile_picture')->getClientOriginalExtension();
                    $fll =  $request->file('profile_picture')->move($destinationPath, $fileName);

                    // update data

                    $res = DB::select(DB::raw('update tbl_user_register set fullname = "'.$fullname.'", lat ="'.$request->input('lat').'",
                            lng = "'.$request->input('lng').'", profile_picture= "'.$fileName.'" where id ='.$user->id.'  '));


                      
                      
                   

                 }
                 return Response::json(array(
                    'error'=>false,
                    'content'=>'User Profile Updated',
                    'token'=>$request->only('token')
                    ),200);
            }
            return Response::json(array(
                'error'=>true,
                'auth_check'=>0,
                'content'=>'User Not Authenticate'
                ),200);

    }


    public function get_user_profile(Request $request){
        $rules = [
        'token'=>'required'
        ];  

        $v = Validator::make($request->all(),$rules);
        if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
                
                if($user->id>0){
                    $res = Db::table('tbl_user_register')
                    ->select('fullname','username','lat','lng','profile_picture')
                    ->where('id','=',$user->id)
                    ->get();
                    return Response::json(array(
                        'error'=>false,
                        'token'=>$request->input('token'),
                        'content'=>$res
                        ),200);       
                }

       return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    public function create_door(Request $Request){
        $rules = [
            'token'=>'required',
            'door_title'=>'required',
            'door_image'=>'required',
            'door_lat'=>'required',
            'door_lng'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
        if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
                
                if($user->id>0){
                    $res = Db::table('tbl_user_register')
                    ->select('fullname','username','lat','lng','profile_picture')
                    ->where('id','=',$user->id)
                    ->get();
                    return Response::json(array(
                        'error'=>false,
                        'token'=>$request->input('token'),
                        'content'=>$res
                        ),200);       
                }

       return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);


    }






}
