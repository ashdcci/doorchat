<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use Response;
use Redirect;
use DB;
use app\Event;
use Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Support\JsonableInterface;
use Illuminate\Contracts\Auth\Guard;
use App\User;
use Session;
use Hash;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Storage;
use Illuminate\Contracts\Filesystem\Factory;
use File;
//use Illuminate\Support\Facades\File;

class DoorchatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {
        //

        return Response::json(array(
            'error'=>true,
            'content'=>'User Not Authenticate to Access this Operation.'
            ),200);
    }   



    public function edit_user_profile(Request $request){
            $rules = [
            'lat'=>'required',
            'fullname'=>'required',
            'lng'=>'required',
            'token'=>'required'
            ];
               

            $v1 = Validator::make($request->all(),$rules);
            if($v1->fails()){
                return Response::json(array(
                    'error'=>false,
                    'content'=>$v1->errors()
                    ),200);
            }

        $user = User::where('user_token', '=', $request->only('token'))->first();
        if(!empty($user)){
                   
            if($user->id>0){
                 $fullname  =  str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('fullname'));
         
                        if (!($request->hasFile('profile_picture'))) {
                            //profile pic not exist
                         

                            $res = DB::select(DB::raw('update tbl_user_register set fullname = "'.$fullname.'", lat ="'.$request->input('lat').'",
                            lng = "'.$request->input('lng').'" where id ='.$user->id.'  '));
                 }else{

                  
                    //delete file
                      File::delete('public/uploads/user_profile/'.$user->profile_picture);
                  
                      //move file
                    $destinationPath =   base_path() . '/public/uploads/user_profile/';
                    $fileName =rand(11111,99999).'.'.$request->file('profile_picture')->getClientOriginalExtension();
                    $fll =  $request->file('profile_picture')->move($destinationPath, $fileName);

                    // update data

                    $res = DB::select(DB::raw('update tbl_user_register set fullname = "'.$fullname.'", lat ="'.$request->input('lat').'",
                            lng = "'.$request->input('lng').'", profile_picture= "'.$fileName.'" where id ='.$user->id.'  '));       

                 }
                 if($res>0){
                    return Response::json(array(
                    'error'=>false,
                    'content'=>'User Profile Updated',
                    'token'=>$request->only('token')
                    ),200);
                 }
                 return Response::json(array(
                    'error'=>true,
                    'content'=>'Problam in Update User Data',
                    'token'=>$request->only('token')
                    ),200);
                 
            }
        }

            return Response::json(array(
                'error'=>true,
                'auth_check'=>0,
                'content'=>'User Not Authenticate'
                ),200);

    }


    public function get_user_profile(Request $request){

        $rules = [
        'token'=>'required'
        ];  

        $v = Validator::make($request->all(),$rules);
        if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        
        $user = User::where('user_token', '=', $request->only('token'))->first();

                if(!empty($user)){
                    if($user->id>0){
                    $res = Db::table('tbl_user_register')
                    ->select('fullname','username','lat','lng','profile_picture')
                    ->where('id','=',$user->id)
                    ->get();

                    if(count($res)>0){
                         return Response::json(array(
                        'error'=>false,
                        'token'=>$request->input('token'),
                        'content'=>$res
                        ),200);         
                    }
                     return Response::json(array(
                        'error'=>true,
                        'token'=>$request->input('token'),
                        'content'=>'Data not Fetched'
                        ),200);    
                    
                    }  
                }

       return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    public function create_door(Request $request){
        $rules = [
            'token'=>'required',
            'door_title'=>'required',
            'door_image'=>'required',
            'door_lat'=>'required',
            'door_lng'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
        if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
                
            if(!empty($user)){
                if($user->id>0){
         

                     if (!($request->hasFile('door_image'))) {
                        return Response::json(array(
                            'error'=>true,
                            'content'=>'File Not Exist'
                            ),200);
                     }else{
                        $destinationPath =   base_path() . '/public/uploads/door_uploads/';
                        $fileName =rand(11111,99999).'.'.$request->file('door_image')->getClientOriginalExtension();
                        $fll =  $request->file('door_image')->move($destinationPath, $fileName);
                     }

                    $res = Db::table('tbl_door')->insertGetId([
                        'door_title'=>$request->input('door_title'),
                        'door_image'=>$fileName,
                        'user_id'=>$user->id,
                        'door_lat'=>$request->input('door_lat'),
                        'door_lng'=>$request->input('door_lng')
                        ]);
                    if($res>0){
                        return Response::json(array(
                        'error'=>false,
                        'token'=>$request->input('token'),
                        'content'=>'Door Generaterd',
                        'recent_door_id'=>$res
                        ),200);  
                    }
                    return Response::json(array(
                        'error'=>true,
                        'token'=>$request->input('token'),
                        'content'=>'Problam in Door Generation/Insert Error Occur'
                        ),200);  
                         
                }
            }

       return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);


    }


    public function update_door_info(Request $request){
        $rules = [
        'door_id'=>'required',
        'token'=>'required',
        'door_title'=>'required',
        'door_lat'=>'required',
        'door_lng'=>'required'
        ];


        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

        $user = User::where('user_token', '=', $request->only('token'))->first();
                 $door_title = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('door_title'));
            if(!empty($user)){
                if($user->id>0){
                   if (!($request->hasFile('door_image'))) {
                   
                      // if door image not exist

                       $res = DB::select(DB::raw('update tbl_door set door_title ="'.$door_title.'",door_lat = '.$request->input('door_lat').',
                        door_lng ='.$request->input('door_lng').' where id = '.$request->input('door_id').' and user_id = '.$request->input('user_id').' '));


                     }else{
                        // door image exist

                        // fetch old door image
                        $ress = DB::table('tbl_door')->select('id','door_image')->where('user_id','=',$user->id)->get();
                      
                        if(count($ress)>0){
                             
                            foreach($ress  as $val){
                                //echo $val->door_image;
                                File::delete('public/uploads/door_uploads/'.$val->door_image);
                            }

                        }

                        // upload new image and get file name
                        $destinationPath =   base_path() . '/public/uploads/door_uploads/';
                        $fileName =rand(11111,99999).'.'.$request->file('door_image')->getClientOriginalExtension();
                        $fll =  $request->file('door_image')->move($destinationPath, $fileName);


                        // now set data to be update
                        $res = DB::select(DB::raw('update tbl_door set door_title ="'.$door_title.'",door_lat = '.$request->input('door_lat').',
                        door_lng ='.$request->input('door_lng').',door_image = "'.$fileName.'" where id = '.$request->input('door_id').'
                         and user_id = '.$user->id.' '));

                        
                     }

                      if($res>0){
                            return Response::json(array(
                            'error'=>false,
                            'content'=>'Door Info Updated',
                            'token'=>$request->input('token')
                            ),200);
                        }
                       return Response::json(array(
                            'error'=>true,
                            'content'=>'Door Info Updated Error Occur',
                            'token'=>$request->input('token')
                            ),200);


                }
                return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }



    public function delete_door(){
        $rules = [
        'token'=>'required',
        'door_id'=>'required'
        ];
         $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    $res =  DB::table('tbl_door')
                            ->where('id','=',$request->input('door_id'))
                            ->where('user_id','=',$user->id)
                            ->delete();
                            if($res>0){
                                return Response::json(array(
                                'error'=>false,
                                'content'=>'Door Deleted',
                                'token'=>$request->input('token')
                                ),200);
                            }
                            return Response::json(array(
                                'error'=>true,
                                'content'=>'Problam in Door Deleting/Delete Error Occur',
                                'token'=>$request->input('token')
                                ),200);
                  }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function add_visited_door(Request $request){

         $rules = [
        'token'=>'required',
        'door_id'=>'required'
        ];
         $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){

                    $re1 = DB::table('tbl_door_visited')
                    ->where('visitor_id','=',$user->id)
                    ->where('door_id','=',$request->input('door_id'))
                    ->get();
                    if(count($re1)==0){

                        $res = DB::table('tbl_door_visited')->insertGetId([
                        'door_id'=>$request->input('door_id'),
                        'visitor_id'=>$user->id,
                        'visit_time'=>date('Y-m-d H:i:s')
                        ]);
                             
                    }else{
                        
                        $res = DB::select(DB::raw('update tbl_door_visited set visit_time = "'.date('Y-m-d H:i:s').'" where visitor_id = '.$user->id.' 
                            and door_id = '.$request->input('door_id').' '));

                    }

                    if($res>0){
                        return Response::json(array(
                                'error'=>false,
                                'content'=>'Door Visited',
                                'token'=>$request->input('token')
                                ),200);
                    }
                    return Response::json(array(
                                'error'=>true,
                                'content'=>'Error in Door Visiting/Data Insert Error occur',
                                'token'=>$request->input('token')
                                ),200);

                   
                  }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    public function delete_visited_door(Request $request){
         $rules = [
        'token'=>'required',
        'door_id'=>'required'
        ];
         $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                     $res =  DB::table('tbl_door_visited')
                            ->where('door_id','=',$request->input('door_id'))
                            ->where('visitor_id','=',$user->id)
                            ->delete();
                            if($res>0){
                                return Response::json(array(
                                'error'=>false,
                                'content'=>'Visited Door Deleted',
                                'token'=>$request->input('token')
                                ),200);
                            }
                            return Response::json(array(
                                'error'=>true,
                                'content'=>'Problam in Deleting of Visited Door',
                                'token'=>$request->input('token')
                                ),200);
                            
                  }
                    return Response::json(array(
                            'error'=>true,
                            'auth_check'=>0,
                            'content'=>'User Not Authenticate'
                            ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    public function add_report_door(Request $request){
       $rules = [
        'token'=>'required',
        'door_id'=>'required',
        'report_title' =>'required',
        'report_desc'=>'required'
        ];
         $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    $report_title = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('report_title'));
                    $report_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('report_desc'));

                    $res = DB::table('tbl_door_report')->insertGetId([
                        'door_id'=>$request->input('door_id'),
                        'report_title'=>$report_title,
                        'report_desc'=>$report_desc
                        ]);

                    if($res>0){
                            return Response::json(array(
                                'error'=>false,
                                'content'=>'Report Generaterd to This Door',
                                'token'=>$request->input('token')
                                ),200);
                    }
                    return Response::json(array(
                                'error'=>true,
                                'content'=>'Error in Report Generating to This Door',
                                'token'=>$request->input('token')
                                ),200);        
                  }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    // Door Post Module
    public function add_door_post(Request $request){
        $rules = [
        'token'=>'required',
        'post_desc'=>'required',
        'door_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){

                  if (!($request->hasFile('post_image'))) {
                            //post image pic not exist
                         

                    $post_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('post_desc'));
                    $res = DB::table('tbl_door_post')->insertGetId([
                        'door_id'=>$request->input('door_id'),
                        'user_id'=>$user->id,
                        'post_desc'=>$post_desc
                        ]);

                 }else{

                      //move file
                    $destinationPath =   base_path() . '/public/uploads/post_image/';
                    $fileName =rand(11111,99999).'.'.$request->file('post_image')->getClientOriginalExtension();
                    $fll =  $request->file('post_image')->move($destinationPath, $fileName);
                   
                    $post_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('post_desc'));
                    $res = DB::table('tbl_door_post')->insertGetId([
                        'door_id'=>$request->input('door_id'),
                        'user_id'=>$user->id,
                        'post_image'=>$fileName,
                        'post_desc'=>$post_desc
                        ]);

                }

                    if($res>0){
                        return Response::json(array(
                            'error'=>false,
                            'content'=>'Door Post Created',
                            'door_id'=>$request->input('door_id'),
                            'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                            'error'=>true,
                            'content'=>'Error in Post Creation'
                        ),200);
                }

             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function delete_door_post(Request $request){
        $rules = [
        'token'=>'required',
        'post_id'=>'required',
        'door_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                     $res = DB::table('tbl_door_post')
                            ->where('user_id','=',$user->id)
                            ->where('id','=',$request->input('post_id'))
                            ->where('door_id','=',$request->input('door_id'))
                            ->delete();
                    if($res>0){
                       return Response::json(array(
                        'error'=>false,
                        'content'=>'Post Deleted',
                        'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                    'error'=>true,
                    'content'=>'Post Delete Error Occured',
                    'token'=>$request->input('token')
                    ),200);
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);

    }

    public function update_door_post(Request $request){
        $rules = [
        'token'=>'required',
        'id'=>'required',
        'door_id'=>'required',
        'post_desc'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                  $post_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('post_desc'));
                    // $res = DB::select(DB::raw('update tbl_door_post a left join tbl_door b on a.door_id = b.id left join tbl_user_register c
                    //  on a.user_id = c.id  set a.post_desc = "'.$post_desc.'" where a.id = '.$request->input('id').' and 
                    //  a.door_id = '.$request->input('door_id').' and a.user_id = '.$user->id.' '));


                  $res = DB::table('tbl_door_post as a')
                            ->leftJoin('tbl_door as b','a.door_id','=','b.id')
                            ->leftJoin('tbl_user_register as c','a.user_id','=','c.id')
                            ->where('a.door_id','=',$request->input('door_id'))
                            ->where('a.user_id','=',$user->id)
                            ->where('a.id','=',$request->input('id'))
                            ->update(['a.post_desc'=>$post_desc]);


                    if($res > 0){
                       return Response::json(array(
                        'error'=>false,
                        'content'=>'Post Updated',
                        'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                    'error'=>true,
                    'content'=>'Post Update Error Occured',
                    'token'=>$request->input('token')
                    ),200);
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function door_post_like(Request $request){
         $rules = [
        'token'=>'required',
        'id'=>'required',
        'door_id'=>'required',
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
        
                    $re1 = DB::table('tbl_door_post_likes')
                            ->select('*')
                            ->where('door_id','=',$request->input('door_id'))
                            ->where('post_id','=',$request->input('id'))
                            ->where('liker_id','=',$user->id)
                            ->get();
                           
                            if(count($re1)>0){
                                // then dislike and decr post like count
                                $r1 = DB::table('tbl_door_post_likes')
                                    ->where('liker_id','=',$user->id)
                                    ->where('post_id','=',$request->input('id'))
                                    ->where('door_id','=',$request->input('door_id'))
                                    ->delete();

                                 $u1 = DB::select(DB::raw('update tbl_door_post set like_count = like_count-1 where door_id = '.$request->input('door_id').' and 
                                 user_id = '.$user->id.' and id = '.$request->input('id').' and like_count>0 '));   
                                 
                                 if($u1 > 0){
                                       return Response::json(array(
                                        'error'=>false,
                                        'content'=>'Post Unlike',
                                        'token'=>$request->input('token')
                                        ),200);
                                    }
                                    return Response::json(array(
                                    'error'=>true,
                                    'content'=>'Post Like Error Occured',
                                    'token'=>$request->input('token')
                                    ),200);
                            }else{
                                // then like and incr post like count

                                $r1 = DB::table('tbl_door_post_likes')->insertGetId([
                                    'post_id'=>$request->input('id'),
                                    'liker_id'=>$user->id,
                                    'door_id'=>$request->input('door_id')
                                    ]);
                                 $u1 = DB::select(DB::raw('update tbl_door_post set like_count = like_count+1 where door_id = '.$request->input('door_id').' and 
                                 user_id = '.$user->id.' and id = '.$request->input('id').' '));
                                 if($u1 > 0){
                                       return Response::json(array(
                                        'error'=>false,
                                        'content'=>'Post Likes',
                                        'token'=>$request->input('token')
                                        ),200);
                                    }
                                    return Response::json(array(
                                    'error'=>true,
                                    'content'=>'Post Like Error Occured',
                                    'token'=>$request->input('token')
                                    ),200);
                            }


                    
                    
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    // fetch door post

    public function fetch_door_post(Request $request){
         $rules = [
        'token'=>'required',
        'door_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    // $res = DB::select(DB::raw('select distinct a.id,a.door_id,a.post_desc,b.fullname,b.profile_picture from tbl_door_post a,tbl_user_register b,
                    //     tbl_door c where a.user_id = b.id and a.door_id = c.id order by a.id desc'));
                        $res =DB::table('tbl_door_post as a')
                                ->selectRaw('a.id,a.door_id,a.post_desc,b.fullname,b.profile_picture')
                                ->leftJoin('tbl_user_register as b','a.user_id', '=', 'b.id')
                                ->leftJoin('tbl_door as c','a.door_id', '=', 'c.id')
                                ->orderBy('a.id', 'DESC')
                                ->where('a.door_id', $request->input('door_id'))
                                ->paginate(10);

                     if(count($res)>0){
                        return Response::json(array(
                            'error'=>false,
                            'content'=>$res->toArray()
                            ),200);
                    }
                    return Response::json(array(
                        'error'=>true,
                        'content'=>'Door Post Fetch Error Occured',
                         'token'=>$request->input('token')
                        ),200);
                }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }


    // End Door Post Module

    // Door Post Comment Module

    public function add_door_post_comment(Request $request){

         $rules = [
        'token'=>'required',
        'comment_desc'=>'required',
        'door_id'=>'required',
        'post_id'=>'required',
        'p_comment_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }
        $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    $comment_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('comment_desc'));
                    // fetch where this is a first post 
                   
                            if($request->input('p_comment_id')>0){
                              
                                // not a first post

                                $pc = DB::table('tbl_door_post_comment')
                                           ->where('door_id', $request->input('door_id'))
                                           ->where('post_id', $request->input('post_id'))
                                           ->where('id', $request->input('p_comment_id'))
                                           ->get();
                                          
                                           if(count($pc)>0){
                                            // pcomment id really related to this post and door id
                                            $res = DB::table('tbl_door_post_comment')->insertGetId([
                                                     'door_id'=>$request->input('door_id'),
                                                        'commenter_id'=>$user->id,
                                                        'post_comment_desc'=>$comment_desc,
                                                        'post_id'=>$request->input('post_id'),
                                                        'parent_comment_id'=>$request->input('p_comment_id')
                                                    ]);
                                            // update comment_count to its parent id
                                            $u1 = DB::table('tbl_door_post_comment')
                                                    ->where('door_id', $request->input('door_id'))
                                                    ->where('post_id', $request->input('post_id'))
                                                    ->where('id', $request->input('p_comment_id'))
                                                    ->increment('comment_count');
                                           }else{
                                            // p comment id not relate to this post and door
                                             return Response::json(array(
                                                    'error'=>true,
                                                    'content'=>'Parent Comment id not belong to this Door and post'
                                                ),200);
                                           }

                                    

                            }else{
                                // first post
                                 
                                    $res = DB::table('tbl_door_post_comment')->insertGetId([
                                        'door_id'=>$request->input('door_id'),
                                        'commenter_id'=>$user->id,
                                        'post_comment_desc'=>$comment_desc,
                                        'post_id'=>$request->input('post_id'),
                                        'parent_comment_id'=>'0'
                                        ]);

                                    // update comment_count to original post here
                                    $u1 = DB::table('tbl_door_post')
                                                    ->where('door_id', $request->input('door_id'))
                                                    ->where('user_id', $user->id)
                                                    ->increment('comment_count');
                            }

                    
                    if($res>0){
                        return Response::json(array(
                            'error'=>false,
                            'content'=>'Door Post Comment Created',
                            'door_id'=>$request->input('door_id'),
                            'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                            'error'=>true,
                            'content'=>'Error in Post Comment Creation'
                        ),200);
                }

             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function update_door_post_comment(Request $request){
           $rules = [
        'token'=>'required',
        'comment_desc'=>'required',
        'door_id'=>'required',
        'post_id'=>'required',
        'comment_id'=>'required',
        'p_comment_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                  $comment_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('comment_desc'));
                    
                 
                    $res = DB::table('tbl_door_post_comment as a')
                            ->leftJoin('tbl_door_post as b','a.post_id','=','b.id')
                            ->leftJoin('tbl_door as c','a.door_id','=','c.id')
                            ->leftJoin('tbl_user_register as d','a.commenter_id','=','d.id')
                            ->where('a.door_id','=',$request->input('door_id'))
                            ->where('a.post_id','=',$request->input('post_id'))
                            ->where('a.parent_comment_id','=',$request->input('p_comment_id'))
                            ->where('a.id','=',$request->input('comment_id'))
                            ->update(['a.post_comment_desc'=>$comment_desc]);

                    if($res > 0){
                       return Response::json(array(
                        'error'=>false,
                        'content'=>'Post Comment Updated',
                        'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                    'error'=>true,
                    'content'=>'Post Comment Update Error Occured',
                    'token'=>$request->input('token')
                    ),200);
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function delete_door_post_comment(Request $request){
          $rules = [
        'token'=>'required',
        'door_id'=>'required',
        'post_id'=>'required',
        'comment_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                  $comment_desc = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $request->input('comment_desc'));
                    $res1 = DB::table('tbl_door_post_comment')
                            ->selectRaw('id,parent_comment_id')
                            ->where('post_id','=',$request->input('post_id'))
                            ->where('door_id','=',$request->input('door_id'))
                            ->where('commenter_id','=',$user->id)
                            ->where('id','=',$request->input('comment_id'))
                            ->first();
                           
                    if($res1->parent_comment_id >0){
                        // decrease comment count from its parent comment id in tbl_door_post_comment
                         $res = DB::select(DB::raw('delete from tbl_door_post_comment where id = '.$request->input('comment_id').' 
                        and post_id = '.$request->input('post_id').' and door_id = '.$request->input('door_id').' and commenter_id ='.$user->id.' '));

                         $des = DB::select(DB::raw('update tbl_door_post_comment set comment_count = comment_count-1 where id = '.$res1->parent_comment_id.' 
                        and post_id = '.$request->input('post_id').' and door_id = '.$request->input('door_id').' '));
                    }else{

                        // decrease parent comment count from tbl_door_post
                        $res = DB::select(DB::raw('delete from tbl_door_post_comment where id = '.$request->input('comment_id').' 
                        and post_id = '.$request->input('post_id').' and door_id = '.$request->input('door_id').' and commenter_id ='.$user->id.' and parent_comment_id = '.$res1->id.' '));

                        $des = DB::select(DB::raw('update tbl_door_post set comment_count  = comment_count - 1 where id ='.$request->input('post_id').'
                            and door_id = '.$request->input('door_id').' '));
                    }
                             
                    if($res > 0){
                       return Response::json(array(
                        'error'=>false,
                        'content'=>'Post Comment Deleted',
                        'token'=>$request->input('token')
                        ),200);
                    }
                    return Response::json(array(
                    'error'=>true,
                    'content'=>'Post Comment Delete Error Occured',
                    'token'=>$request->input('token')
                    ),200);
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }



    public function door_post_comment_like(Request $request){
         $rules = [
        'token'=>'required',
        'id'=>'required',//comment id
        'door_id'=>'required',
        'post_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
        
                    $re1 = DB::table('tbl_door_post_comment_likes')
                            ->select('*')
                            ->where('door_id','=',$request->input('door_id'))
                            ->where('post_id','=',$request->input('post_id'))
                            ->where('liker_id','=',$user->id)
                            ->where('comment_id','=',$request->input('id'))
                            ->get();
                            if(count($re1)>0){
                                // then dislike and decr post comment like count
                                $r1 = DB::table('tbl_door_post_comment_likes')
                                    ->where('liker_id','=',$user->id)
                                    ->where('comment_id','=',$request->input('id'))
                                    ->where('post_id','=',$request->input('post_id'))
                                    ->where('door_id','=',$request->input('door_id'))
                                    ->delete();

                                 $u1 = DB::select(DB::raw('update tbl_door_post_comment set comment_like_count = comment_like_count-1 where door_id = '.$request->input('door_id').' and 
                                 post_id = '.$request->input('post_id').' and commenter_id = '.$user->id.' and id = '.$request->input('id').' and comment_like_count>0 '));   
                                 if($u1 > 0){
                                       return Response::json(array(
                                        'error'=>false,
                                        'content'=>'Post Comment Unliked',
                                        'token'=>$request->input('token')
                                        ),200);
                                    }
                                    return Response::json(array(
                                    'error'=>true,
                                    'content'=>'Post Comment Like Error Occured',
                                    'token'=>$request->input('token')
                                    ),200);
                            }else{
                                // then like and incr post like count

                                $r1 = DB::table('tbl_door_post_comment_likes')->insertGetId([
                                    'post_id'=>$request->input('post_id'),
                                    'comment_id'=>$request->input('id'),
                                    'liker_id'=>$user->id,
                                    'door_id'=>$request->input('door_id')
                                    ]);
                                 $u1 = DB::select(DB::raw('update tbl_door_post_comment set comment_like_count = comment_like_count+1 where door_id = '.$request->input('door_id').' and 
                                 commenter_id = '.$user->id.' and post_id = '.$request->input('post_id').' and id = '.$request->input('id').' '));
                                 
                                 if($u1 > 0){
                                       return Response::json(array(
                                        'error'=>false,
                                        'content'=>'Post Comment Liked',
                                        'token'=>$request->input('token')
                                        ),200);
                                    }
                                    return Response::json(array(
                                    'error'=>true,
                                    'content'=>'Post Like Error Occured',
                                    'token'=>$request->input('token')
                                    ),200);
                            }


                    
                    
                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    //fetch_door_post_comment

    public function fetch_door_post_comment(Request $request){
         $rules = [
        'token'=>'required',
        'door_id'=>'required',
        'post_id'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    if($request->has('p_comment_id')){
                        // means get inner comment form particular comments
                             $res = DB::table('tbl_door_post_comment as a')
                                ->selectRaw('distinct a.id,a.parent_comment_id,a.post_comment_desc,c.fullname,c.profile_picture,a.comment_like_count,a.comment_count')
                                ->join('tbl_door_post as b','a.post_id','=','b.id')
                                ->join('tbl_user_register as c','a.commenter_id','=','c.id')
                                ->join('tbl_door as d','a.door_id','=','d.id')
                                ->where('a.door_id','=',$request->input('door_id'))
                                ->where('a.post_id','=',$request->input('post_id'))
                                ->where('a.parent_comment_id','=',$request->input('p_comment_id'))
                                ->orderBy('a.id','DESC')
                                ->paginate(10); 
                    }else{
                        // means get all parent comment
                        $res = DB::table('tbl_door_post_comment as a')
                                ->selectRaw('distinct a.id,a.parent_comment_id,a.post_comment_desc,c.fullname,c.profile_picture,a.comment_like_count,a.comment_count')
                                ->join('tbl_door_post as b','a.post_id','=','b.id')
                                ->join('tbl_user_register as c','a.commenter_id','=','c.id')
                                ->join('tbl_door as d','a.door_id','=','d.id')
                                ->where('a.door_id','=',$request->input('door_id'))
                                ->where('a.post_id','=',$request->input('post_id'))
                                ->where('a.parent_comment_id','0')
                                ->orderBy('a.id','DESC')
                                ->paginate(10);  
                    }

                    return Response::json(array(
                        'error'=>false,
                        'content'=>$res->toArray()
                        ),200);

                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }





    // End door post comment module



    // fetch my door screen

    public function my_door_screen(Request $request){
         $rules = [
        'token'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    // my doors
                    $profile []= array('fullname'=>$user->fullname,'profile_picture'=>$user->profile_picture);
                    $mydoor = DB::select(DB::raw('select id,door_title,door_image from tbl_door where user_id = '.$user->id.' order by id limit 0,1 '));

                    //neighbourhood doors
                    $ndoor = DB::select(DB::raw('select id,door_title,door_image from tbl_door where user_id <>'.$user->id.' order by id desc limit 0,2 '));

                    
                    return Response::json(array(
                        'error'=>false,
                        'content'=>'data Fetched',
                        'my_profile'=>$profile,
                        'myDoor'=>$mydoor,
                        'neighbour'=>$ndoor,
                        'token'=>$request->input('token')
                        ),200);
                }
                
           return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }

    public function manage_door_list(Request $request){
         $rules = [
        'token'=>'required'
        ];

        $v = Validator::make($request->all(),$rules);
         if($v->fails()){
             return Response::json(array(
                        'error'=>false,
                        'content'=>$v->errors()
                        ),200);
        }

         $user = User::where('user_token', '=', $request->only('token'))->first();
            if(!empty($user)){
                if($user->id>0){
                    $myCreatedDoors = DB::table('tbl_door as a')
                                        ->selectRaw('a.id,a.door_title,a.door_image,a.door_total_member,a.last_active')
                                        ->join('tbl_user_register as b','a.user_id','=','b.id')
                                        ->where('a.user_id','=',$user->id)
                                        ->orderBy('a.id','DESC')
                                        ->paginate(10);

                    $myVisitedDoors = DB::table('tbl_door_visited as a')
                                        ->selectRaw('b.id,b.door_title,b.door_image,b.door_total_member,b.last_active')
                                        ->join('tbl_door as b','a.door_id','=','b.id')
                                        ->join('tbl_user_register as c','a.visitor_id','=','c.id')
                                        ->where('a.visitor_id','=',$user->id)
                                        ->orderBy('a.id','DESC')
                                        ->paginate(10);

                    return Response::json(array(
                        'error'=>false,
                        'content'=>'Data Fetched',
                        'total_mycreated'=>count($myCreatedDoors),
                        'total_visited'=>count($myVisitedDoors),
                        'myCreatedDoors'=>$myCreatedDoors->toArray(),
                        'myVisitedDoors'=>$myVisitedDoors->toArray(),
                        'token'=>$request->input('token')
                        ),200);

                }
             return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
            }
            return Response::json(array(
                    'error'=>true,
                    'auth_check'=>0,
                    'content'=>'User Not Authenticate'
                    ),200);
    }





    




















}
